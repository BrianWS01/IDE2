document.addEventListener("DOMContentLoaded", function () {
    const blocklyDiv = document.getElementById('blocklyDiv');
    const toolbox = document.getElementById('toolbox');
    const codeOutput = document.getElementById('pythonCode');

    // Defines Custom Blocks using Google Blockly JSON format
    Blockly.defineBlocksWithJsonArray([
        {
            "type": "event_when_started",
            "message0": "Quando Iniciar 🚀",
            "nextStatement": null,
            "colour": "#F6B316",
            "tooltip": "Início da execução do MicroPython.",
            "helpUrl": ""
        },
        {
            "type": "mcu_pin_setup",
            "message0": "Configurar Pino %1 como %2",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 2, "min": 0, "max": 40 },
                { "type": "field_dropdown", "name": "MODE", "options": [["SAÍDA (OUTPUT)", "Pin.OUT"], ["ENTRADA (INPUT)", "Pin.IN"], ["ENTRADA COM PULL-UP", "Pin.IN, Pin.PULL_UP"]] }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#8e44ad",
            "tooltip": "Configura se o pino GPIO vai enviar dados (SAÍDA) ou receber (ENTRADA).",
            "helpUrl": ""
        },
        {
            "type": "mcu_pin_write",
            "message0": "Ajustar Pino %1 para %2",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 2 },
                { "type": "field_dropdown", "name": "VAL", "options": [["HIGH (Ligado)", "1"], ["LOW (Desligado)", "0"]] }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#8e44ad",
            "tooltip": "Envia um sinal de 3.3v ou 5v (1) ou 0v (0) para o pino escolhido.",
            "helpUrl": ""
        },
        {
            "type": "mcu_pin_read",
            "message0": "Ler Pino %1",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 2 }
            ],
            "output": "Number",
            "colour": "#8e44ad",
            "tooltip": "Lê o sinal vindo do pino.",
            "helpUrl": ""
        },
        {
            "type": "mcu_pwm_setup",
            "message0": "Ativar PWM no Pino %1 Freq: %2",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 2 },
                { "type": "field_number", "name": "FREQ", "value": 1000 }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#3498db",
            "tooltip": "Inicia um sinal PWM (bom para LEDs dimmers e Motores DC).",
            "helpUrl": ""
        },
        {
            "type": "mcu_pwm_duty",
            "message0": "Ajustar PWM Pino %1 - Força(0-1023): %2",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 2 },
                { "type": "field_number", "name": "DUTY", "value": 512, "min": 0, "max": 1023 }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#3498db",
            "tooltip": "Define a intensidade do pulso.",
            "helpUrl": ""
        },
        {
            "type": "mcu_servo_setup",
            "message0": "Configurar Servomotor no Pino %1",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 15 }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#e74c3c",
            "tooltip": "Prepara um pino para comunicação com MicroServo 9g (ou similar).",
            "helpUrl": ""
        },
        {
            "type": "mcu_servo_move",
            "message0": "Graus do Servo do Pino %1 para %2°",
            "args0": [
                { "type": "field_number", "name": "PIN", "value": 15 },
                { "type": "field_number", "name": "ANGLE", "value": 90, "min": 0, "max": 180 }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#e74c3c",
            "tooltip": "Move o braço do motor para o ângulo exato (0 a 180 graus).",
            "helpUrl": ""
        },
        {
            "type": "mcu_sleep",
            "message0": "Aguardar %1 segundos ⏳",
            "args0": [
                { "type": "field_number", "name": "SECONDS", "value": 1 }
            ],
            "previousStatement": null,
            "nextStatement": null,
            "colour": "#e67e22",
            "tooltip": "Pausa a execução do seu código pelo tempo determinado.",
            "helpUrl": ""
        }
    ]);

    const pyGen = window.python ? window.python.pythonGenerator : window.Blockly.Python;

    if (!pyGen) {
        codeOutput.textContent = "# Erro crítico: Gerador Python do Blockly não encontrado.";
        return;
    }

    // --- Smart Combined Imports Logic ---
    // Engaja no ciclo de vida do Workspace do código Python
    const origInit = pyGen.init;
    pyGen.init = function (workspace) {
        origInit.call(this, workspace);
        this.machineImports_ = new Set(); // Guarda classes como 'Pin', 'PWM'
    };

    const origFinish = pyGen.finish;
    pyGen.finish = function (code) {
        // Se alguma classe da machine foi detectada, combina numa única linha
        if (this.machineImports_ && this.machineImports_.size > 0) {
            // Sort garante consistência visual (ex: from machine import PWM, Pin)
            const imports = Array.from(this.machineImports_).sort().join(', ');
            this.definitions_['import_machine_combined'] = `from machine import ${imports}`;
        }
        return origFinish.call(this, code);
    };
    // ------------------------------------

    pyGen.forBlock['event_when_started'] = function (block, generator) {
        // Agora, os imports são totalmente delegados aos blocos que os usam 
        // e ele não vai mais gerar import machine sozinho se não for usado!
        return "# --- INÍCIO DO SEU PROGRAMA MicroPython ---\n";
    };

    pyGen.forBlock['mcu_pin_setup'] = function (block, generator) {
        generator.machineImports_.add('Pin');
        const pin = block.getFieldValue('PIN');
        const mode = block.getFieldValue('MODE');
        return `pin_${pin} = Pin(${pin}, ${mode})\n`;
    };

    pyGen.forBlock['mcu_pin_write'] = function (block, generator) {
        generator.machineImports_.add('Pin');
        const pin = block.getFieldValue('PIN');
        const val = block.getFieldValue('VAL');
        return `pin_${pin}.value(${val})\n`;
    };

    pyGen.forBlock['mcu_pin_read'] = function (block, generator) {
        generator.machineImports_.add('Pin');
        const pin = block.getFieldValue('PIN');
        return [`pin_${pin}.value()`, generator.ORDER_ATOMIC];
    };

    pyGen.forBlock['mcu_pwm_setup'] = function (block, generator) {
        generator.machineImports_.add('PWM');
        generator.machineImports_.add('Pin');
        const pin = block.getFieldValue('PIN');
        const freq = block.getFieldValue('FREQ');
        return `pwm_${pin} = PWM(Pin(${pin}))\npwm_${pin}.freq(${freq})\n`;
    };

    pyGen.forBlock['mcu_pwm_duty'] = function (block, generator) {
        generator.machineImports_.add('PWM');
        generator.machineImports_.add('Pin'); // Inclui a dependência nativa "Pin"
        const pin = block.getFieldValue('PIN');
        const duty = block.getFieldValue('DUTY');
        return `pwm_${pin}.duty(${duty})\n`;
    };

    pyGen.forBlock['mcu_servo_setup'] = function (block, generator) {
        generator.machineImports_.add('Pin');
        generator.definitions_['import_servo'] = 'from servo import Servo';
        const pin = block.getFieldValue('PIN');
        return `servo_${pin} = Servo(Pin(${pin}))\n`;
    };

    pyGen.forBlock['mcu_servo_move'] = function (block, generator) {
        generator.machineImports_.add('Pin');
        generator.definitions_['import_servo'] = 'from servo import Servo';
        const pin = block.getFieldValue('PIN');
        const angle = block.getFieldValue('ANGLE');
        return `servo_${pin}.write_angle(${angle})\n`;
    };

    pyGen.forBlock['mcu_sleep'] = function (block, generator) {
        generator.definitions_['import_time'] = 'import time';
        const seconds = block.getFieldValue('SECONDS');
        return `time.sleep(${seconds})\n`;
    };

    const themeZelos = Blockly.Theme.defineTheme('zelosCustom', {
        'base': Blockly.Themes.Zelos,
        'startHats': true
    });

    const workspace = Blockly.inject(blocklyDiv, {
        toolbox: toolbox,
        scrollbars: true,
        trashcan: true,
        renderer: 'zelos',
        grid: {
            spacing: 25,
            length: 3,
            colour: '#ccc',
            snap: true
        },
        theme: themeZelos
    });

    function updateCode() {
        let code = pyGen.workspaceToCode(workspace);
        if (!code.trim()) {
            code = "# Conecte blocos abaixo do 'Quando Iniciar' para gerar código...\n";
        }
        codeOutput.textContent = code;

        if (window.Prism) {
            Prism.highlightElement(codeOutput);
        }
    }

    workspace.addChangeListener(updateCode);
    updateCode();

    const startBlock = workspace.newBlock('event_when_started');
    startBlock.initSvg();
    startBlock.render();
    startBlock.moveBy(50, 50);

    window.addEventListener('resize', function () {
        Blockly.svgResize(workspace);
    });

    document.getElementById('btn-copy').addEventListener('click', () => {
        const text = codeOutput.textContent;
        navigator.clipboard.writeText(text).then(() => {
            alert('Código copiado para a área de transferência!');
        });
    });

    document.getElementById('btn-upload').addEventListener('click', () => {
        alert('Este botão conectaria usando a Web Serial API (ex: pyserial / WebUSB) ao dispositivo!')
    });
});
